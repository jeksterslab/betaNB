library(testthat)
library(betaNB)

test_check("betaNB")
