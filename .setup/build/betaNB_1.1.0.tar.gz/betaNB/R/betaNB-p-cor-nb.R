#' Estimate Squared Partial Correlation Coefficients
#' and Generate the Corresponding Sampling Distribution
#' Using Nonparametric Bootstrapping
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @details The vector of squared partial correlation coefficients
#'   (\eqn{pr^{2}_{j}})
#'   is estimated from bootstrap samples.
#'   Confidence intervals are the percentiles
#'   corresponding to \eqn{100(1 - \alpha)\%}
#'   of the sampling distribution of \eqn{pr^{2}_{j}},
#'   where \eqn{\alpha} is the significance level.
#'
#' @details
#' Let \eqn{\boldsymbol{\beta}^{\ast}} be the vector of standardized slopes,
#' \eqn{\boldsymbol{R}_{x}} the correlation matrix of the regressors,
#' \eqn{r^{jj}} the \eqn{j}th diagonal element of \eqn{\boldsymbol{R}_{x}^{-1}},
#' and \eqn{R^{2} = \boldsymbol{\beta}^{\ast\prime} \boldsymbol{R}_{x}
#' \boldsymbol{\beta}^{\ast}}.
#' The semipartial correlation of regressor \eqn{j} is
#' \deqn{sr_{j} = \beta^{\ast}_{j} / \sqrt{r^{jj}} = \beta^{\ast}_{j} \sqrt{1 -
#' R^{2}_{j \cdot -j}},}
#' where \eqn{R^{2}_{j \cdot -j}} is the R-squared from regressing regressor
#' \eqn{j}
#' on the other regressors.
#' Its square, \eqn{sr^{2}_{j}}, is the change in \eqn{R^{2}} when regressor
#' \eqn{j} is added last.
#' Because \eqn{1 / r^{jj} = 1 - R^{2}_{j \cdot -j}}, \eqn{sr_{j}} shrinks
#' toward zero
#' as regressor \eqn{j} becomes more redundant with the other regressors.
#' The squared partial correlation is
#' \deqn{pr^{2}_{j} = \frac{sr^{2}_{j}}{1 - R^{2} + sr^{2}_{j}},}
#' the proportion of the variance in the outcome not explained by the other
#' regressors
#' that is explained by regressor \eqn{j}.
#' Each effect size is computed from every bootstrap sample
#' (see [NB()]), and the confidence intervals are percentile-based.
#'
#' @return Returns an object
#'   of class `betanb` which is a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{Function arguments.}
#'     \item{thetahatstar}{Sampling distribution of
#'       \eqn{pr^{2}_{j}}.}
#'     \item{vcov}{Sampling variance-covariance matrix of
#'       \eqn{pr^{2}_{j}}.}
#'     \item{est}{Vector of estimated
#'       \eqn{pr^{2}_{j}}.}
#'     \item{fun}{Function used ("PCorNB").}
#'   }
#'
#' @inheritParams BetaNB
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaNB")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # NB -----------------------------------------------------------------------
#' nb <- NB(
#'   object = object,
#'   R = 100, # use a large value e.g., 5000L for actual research
#'   seed = 0508
#' )
#'
#' # PCorNB -------------------------------------------------------------------
#' out <- PCorNB(object = nb, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' print(x = out)
#' summary(object = out)
#' coef(object = out)
#' vcov(object = out)
#' confint(object = out, level = 0.95)
#'
#' @family Beta Nonparametric Bootstrap Functions
#' @keywords betaNB pcor
#' @export
PCorNB <- function(object,
                   alpha = c(0.05, 0.01, 0.001)) {
  stopifnot(
    inherits(
      x = object,
      what = "nb"
    )
  )
  if (object$lm_process$p < 2) {
    stop("Two or more regressors is required.")
  }
  fun <- "PCorNB"
  est <- .PCorSq(
    srsq = .SPCor(
      betastar = object$lm_process$betastar,
      sigmacapx = object$lm_process$sigmacapx
    )^2,
    rsq = object$lm_process$rsq[1]
  )
  names(x = est) <- object$lm_process$xnames
  thetahatstar <- object$es$pcorsq
  jackknife <- object$es_jackknife$pcorsq
  vcov <- stats::var(x = thetahatstar)
  colnames(x = vcov) <- rownames(x = vcov) <- names(x = est)
  out <- list(
    call = match.call(),
    args = list(
      object = object,
      alpha = alpha
    ),
    thetahatstar = thetahatstar,
    jackknife = jackknife,
    vcov = vcov,
    est = est,
    fun = fun
  )
  class(x = out) <- c(
    "betanb",
    class(x = out)
  )
  out
}
