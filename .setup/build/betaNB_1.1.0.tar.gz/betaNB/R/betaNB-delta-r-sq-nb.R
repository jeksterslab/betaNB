#' Estimate Improvement in R-Squared
#' and Generate the Corresponding Sampling Distribution
#' Using Nonparametric Bootstrapping
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @details The vector of improvement in R-squared (\eqn{\Delta R^{2}})
#'   is estimated from bootstrap samples.
#'   Confidence intervals are the percentiles
#'   corresponding to \eqn{100(1 - \alpha)\%}
#'   of the sampling distribution of \eqn{\Delta R^{2}},
#'   where \eqn{\alpha} is the significance level.
#'
#'   With `adj = TRUE`, estimates and draws are differences between the
#'   adjusted R-squared values of the full model and the model without
#'   each regressor. The population target remains the unadjusted increment.
#'   Negative adjusted estimates and draws are retained.
#'
#'   With `type = "mpc"` in [confint()] or [summary()], an unadjusted
#'   lower limit is set to zero when the sample F test is nonsignificant.
#'   For adjusted estimates, a nonpositive percentile lower limit becomes
#'   `.001` if significant, or zero if nonsignificant; positive lower
#'   limits are retained. Upper limits are unchanged, without clipping.
#'   Both modes use the unadjusted sample F statistic and test at the
#'   interval's error probability `alpha` (equality is nonsignificant).
#'
#'   These lower-limit rules follow Algina et al. (2007, p. 210;
#'   2008a, pp. 3--5; 2008b, pp. 735, 737; 2010, pp. 928--929, 931--932).
#'   Unlike their ranked endpoints, betaNB retains its ordinary
#'   interpolated percentile calculation. Their studies used pairs
#'   resampling; coverage for wild draws or heteroskedastic F testing
#'   is not established by those studies.
#'
#' @details
#' Let \eqn{\boldsymbol{\beta}^{\ast}} be the vector of standardized slopes,
#' \eqn{\boldsymbol{R}_{x}} the correlation matrix of the regressors,
#' \eqn{r^{jj}} the \eqn{j}th diagonal element of \eqn{\boldsymbol{R}_{x}^{-1}},
#' and \eqn{R^{2} = \boldsymbol{\beta}^{\ast\prime} \boldsymbol{R}_{x}
#' \boldsymbol{\beta}^{\ast}}.
#' The semipartial correlation of regressor \eqn{j} is
#' \deqn{sr_{j} = \beta^{\ast}_{j} / \sqrt{r^{jj}} = \beta^{\ast}_{j} \sqrt{1 -
#' R^{2}_{j \cdot -j}},}
#' where \eqn{R^{2}_{j \cdot -j}} is the R-squared from regressing regressor
#' \eqn{j}
#' on the other regressors.
#' Its square, \eqn{sr^{2}_{j}}, is the change in \eqn{R^{2}} when regressor
#' \eqn{j} is added last.
#' Because \eqn{1 / r^{jj} = 1 - R^{2}_{j \cdot -j}}, \eqn{sr_{j}} shrinks
#' toward zero
#' as regressor \eqn{j} becomes more redundant with the other regressors.
#' The improvement in R-squared for regressor \eqn{j} is
#' \deqn{\Delta R^{2}_{j} = R^{2} - R^{2}_{-j} = sr^{2}_{j}.}
#' Each effect size is computed from every bootstrap sample
#' (see [NB()]), and the confidence intervals are percentile-based.
#'
#' @return Returns an object
#'   of class `betanb` which is a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{Function arguments.}
#'     \item{thetahatstar}{Sampling distribution of
#'       \eqn{\Delta R^{2}}.}
#'     \item{vcov}{Sampling variance-covariance matrix of
#'       \eqn{\Delta R^{2}}.}
#'     \item{est}{Vector of estimated
#'       \eqn{\Delta R^{2}}.}
#'     \item{fun}{Estimator label: `"DeltaRSqNB"` or `"DeltaRSqAdjNB"`.}
#'   }
#'
#' @inheritParams BetaNB
#' @param adj Logical. Use differences in adjusted R-squared.
#'   Default `FALSE` preserves unadjusted estimates and output.
#'
#' @references
#' Algina, J., Keselman, H. J., & Penfield, R. D. (2007).
#' Confidence intervals for an effect size measure
#' in multiple linear regression.
#' *Educational and Psychological Measurement*, *67*(2), 207--218.
#' \doi{10.1177/0013164406292030}
#'
#' Algina, J., Keselman, H. J., & Penfield, R. D. (2008a).
#' Confidence intervals for the squared multiple semipartial
#' correlation coefficient.
#' *Journal of Modern Applied Statistical Methods*, *7*(1), 2--10.
#' \doi{10.22237/jmasm/1209614460}
#'
#' Algina, J., Keselman, H. J., & Penfield, R. D. (2008b).
#' Note on a confidence interval for the squared semipartial
#' correlation coefficient.
#' *Educational and Psychological Measurement*, *68*(5), 734--741.
#' \doi{10.1177/0013164407313371}
#'
#' Algina, J., Keselman, H. J., & Penfield, R. D. (2010).
#' Confidence intervals for squared semipartial correlation coefficients:
#' The effect of nonnormality.
#' *Educational and Psychological Measurement*, *70*(6), 926--940.
#' \doi{10.1177/0013164410379335}
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaNB")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # NB -----------------------------------------------------------------------
#' nb <- NB(
#'   object = object,
#'   R = 100, # use a large value e.g., 5000L for actual research
#'   seed = 0508
#' )
#'
#' # DeltaRSqNB ---------------------------------------------------------------
#' out <- DeltaRSqNB(object = nb, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' print(x = out)
#' summary(object = out)
#' coef(object = out)
#' vcov(object = out)
#' confint(object = out, level = 0.95)
#' confint(object = out, level = 0.95, type = "mpc")
#' adjusted <- DeltaRSqNB(object = nb, alpha = 0.05, adj = TRUE)
#' confint(object = adjusted, level = 0.95, type = "mpc")
#'
#' @family Beta Nonparametric Bootstrap Functions
#' @keywords betaNB deltarsq
#' @export
DeltaRSqNB <- function(object,
                       alpha = c(0.05, 0.01, 0.001),
                       adj = FALSE) {
  stopifnot(
    inherits(
      x = object,
      what = "nb"
    )
  )
  stopifnot(
    is.logical(x = adj),
    length(x = adj) == 1,
    !is.na(x = adj)
  )
  if (object$lm_process$p < 2) {
    stop("Two or more regressors is required.")
  }
  fun <- "DeltaRSqNB"
  est <- .SPCor(
    betastar = object$lm_process$betastar,
    sigmacapx = object$lm_process$sigmacapx
  )^2
  names(x = est) <- object$lm_process$xnames
  thetahatstar <- object$es$spcor^2
  jackknife <- object$es_jackknife$spcor^2
  if (adj) {
    fun <- "DeltaRSqAdjNB"
    est <- .DeltaRSqAdj(
      delta_rsq = est,
      rsq = object$lm_process$rsq[["rsq"]],
      n = object$lm_process$n,
      p = object$lm_process$p
    )
    thetahatstar <- .DeltaRSqAdj(
      delta_rsq = thetahatstar,
      rsq = object$es$rsq[, 1],
      n = object$lm_process$n,
      p = object$lm_process$p
    )
    jackknife <- .DeltaRSqAdj(
      delta_rsq = jackknife,
      rsq = object$es_jackknife$rsq[, 1],
      n = object$lm_process$n - 1,
      p = object$lm_process$p
    )
  }
  vcov <- stats::var(x = thetahatstar)
  colnames(x = vcov) <- rownames(x = vcov) <- names(x = est)
  out <- list(
    call = match.call(),
    args = list(
      object = object,
      alpha = alpha
    ),
    thetahatstar = thetahatstar,
    jackknife = jackknife,
    vcov = vcov,
    est = est,
    fun = fun
  )
  class(x = out) <- c(
    "betanb",
    class(x = out)
  )
  if (adj) {
    out$args$adj <- TRUE
  }
  out
}
