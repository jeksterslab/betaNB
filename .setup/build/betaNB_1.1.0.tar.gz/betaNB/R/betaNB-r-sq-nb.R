#' Estimate R-Squared and Adjusted R-Squared
#' and Generate the Corresponding Sampling Distribution
#' Using Nonparametric Bootstrapping
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @details R-squared (\eqn{R^{2}}) and adjusted R-squared (\eqn{\bar{R}^{2}})
#'   are estimated from bootstrap samples.
#'   Confidence intervals are the percentiles
#'   corresponding to \eqn{100(1 - \alpha)\%}
#'   of the sampling distribution of \eqn{R^{2}} and \eqn{\bar{R}^{2}},
#'   where \eqn{\alpha} is the significance level.
#'
#' @details
#' Let \eqn{\boldsymbol{\beta}^{\ast}} be the vector of standardized slopes,
#' \eqn{\boldsymbol{R}_{x}} the correlation matrix of the regressors,
#' \eqn{r^{jj}} the \eqn{j}th diagonal element of \eqn{\boldsymbol{R}_{x}^{-1}},
#' and \eqn{R^{2} = \boldsymbol{\beta}^{\ast\prime} \boldsymbol{R}_{x}
#' \boldsymbol{\beta}^{\ast}}.
#' The R-squared and the adjusted R-squared are
#' \deqn{R^{2} = \boldsymbol{\beta}^{\ast\prime} \boldsymbol{R}_{x}
#' \boldsymbol{\beta}^{\ast}, \quad \bar{R}^{2} = 1 - \left( 1 - R^{2} \right)
#' \frac{n - 1}{n - k},}
#' where \eqn{n} is the sample size and \eqn{k} is the number of parameters
#' in the regression model, including the intercept.
#' Each effect size is computed from every bootstrap sample
#' (see [NB()]), and the confidence intervals are percentile-based.
#'
#' @return Returns an object
#'   of class `betanb` which is a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{Function arguments.}
#'     \item{thetahatstar}{Sampling distribution of
#'       \eqn{R^{2}} and \eqn{\bar{R}^{2}}.}
#'     \item{vcov}{Sampling variance-covariance matrix of
#'       \eqn{R^{2}} and \eqn{\bar{R}^{2}}.}
#'     \item{est}{Vector of estimated
#'       \eqn{R^{2}} and \eqn{\bar{R}^{2}}.}
#'     \item{fun}{Function used ("RSqNB").}
#'   }
#'
#' @inheritParams BetaNB
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaNB")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # NB -----------------------------------------------------------------------
#' nb <- NB(
#'   object = object,
#'   R = 100, # use a large value e.g., 5000L for actual research
#'   seed = 0508
#' )
#'
#' # RSqNB --------------------------------------------------------------------
#' out <- RSqNB(object = nb, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' print(x = out)
#' summary(object = out)
#' coef(object = out)
#' vcov(object = out)
#' confint(object = out, level = 0.95)
#'
#' @family Beta Nonparametric Bootstrap Functions
#' @keywords betaNB rsq
#' @export
RSqNB <- function(object,
                  alpha = c(0.05, 0.01, 0.001)) {
  stopifnot(
    inherits(
      x = object,
      what = "nb"
    )
  )
  fun <- "RSqNB"
  est <- object$lm_process$rsq
  thetahatstar <- .NBRSqAdj(
    rsq = object$es$rsq,
    lm_process = object$lm_process
  )
  jackknife <- .NBRSqAdj(
    rsq = object$es_jackknife$rsq,
    lm_process = object$lm_process
  )
  vcov <- stats::var(x = thetahatstar)
  colnames(x = vcov) <- rownames(x = vcov) <- names(x = est)
  out <- list(
    call = match.call(),
    args = list(
      object = object,
      alpha = alpha
    ),
    thetahatstar = thetahatstar,
    jackknife = jackknife,
    vcov = vcov,
    est = est,
    fun = fun
  )
  class(x = out) <- c(
    "betanb",
    class(x = out)
  )
  out
}
