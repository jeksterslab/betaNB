# betaNB 1.1.0

## Major

- `NB()` gains the wild bootstrap: `type = "wild"` (default `"pairs"`,
  unchanged), with `weights` (`"rademacher"`, `"mammen"`, `"webb"`,
  `"normal"`), `hc` (`"hc3"`, `"hc0"`, `"hc1"`, `"hc2"`, `"hc4"`,
  `"hc4m"`, `"hc5"`; the same leverage adjustments as betaSandwich), and
  `x` (`"random"` resamples the regressors with their residuals,
  `"fixed"` keeps them). The effect size functions and intervals work on
  the wild draws unchanged. The sampler is in R for now.
- New `FSqNB()` (Cohen's f-squared and the local f-squared of each
  regressor) and `SCorSqNB()` (the image of a signed semipartial interval
  under squaring); equations and definitions in the help pages of the
  effect size functions; a package help page.
- Faster bootstrap: the bootstrap and jackknife covariance matrices
  (closed-form leave-one-out) and the effect sizes are computed in C++
  (Rcpp, RcppArmadillo), once per `NB()` call. The bootstrap samples are
  the same as before for the same seed.

## Minor

- `DeltaRSqNB()` gains `adj = TRUE` for differences in adjusted R-squared.
  `confint()` and `summary()` gain `type = "mpc"` for modified percentile
  intervals of Delta R-squared (sr2), unadjusted or adjusted.
  The sample F test uses the interval's alpha and the unadjusted increment.
  Upper limits and ordinary percentile interpolation are unchanged.
  Existing defaults and `"pc"`, `"bc"`, `"bca"` intervals are unchanged.
- Selective standardization: the arguments `std_y` and `std_x` standardize
  only y or only the named regressors (for example, leave a dummy
  variable in its 0-1 units). The defaults give the same results as
  before.
- The `thetahatstar` and `jackknife` elements of `nb` and `betanb`
  objects are now matrices (one draw per row) instead of lists. `nb`
  objects also hold `es` and `es_jackknife`.
- The internal copies from linearAlgebra 0.0.5 (a faster duplication matrix
  and its inverse), nBootstrap 0.1.0 (quantiles in C++), strRegression
  0.0.2, and processLM 0.0.11 are current.

## Documentation

- The examples name every argument and call `stats::lm()`. The Algina et
  al. references of `DeltaRSqNB()` are in full APA form (2008a, 2008b).

# betaNB 1.0.7

## Patch

* Minor documentation edits.

# betaNB 1.0.6

## Patch

* Minor edits to methods.

# betaNB 1.0.5

## Patch

* Minor documentation edits.

# betaNB 1.0.4

## Patch

* Minor documentation edits.

# betaNB 1.0.3

## Patch

* Minor edits to setting seed.

# betaNB 1.0.2

## Patch

* Edits to documentation.

# betaNB 1.0.1

## Patch

* Edits to the DESCRIPTION file.

# betaNB 1.0.0

## Major

* And so it begins.
