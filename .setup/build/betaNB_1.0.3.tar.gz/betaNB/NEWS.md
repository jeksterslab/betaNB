# betaNB 1.0.3

* Minor edits to setting seed.

# betaNB 1.0.2

## Patch

* Edits to documentation.

# betaNB 1.0.1

## Patch

* Edits to the DESCRIPTION file.

# betaNB 1.0.0

## Major

* And so it begins.
