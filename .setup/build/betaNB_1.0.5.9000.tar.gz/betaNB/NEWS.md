# betaNB 1.0.5.9000

## Patch

* Latest development version.
* Minor edits to tests.

# betaNB 1.0.5

## Patch

* Minor documentation edits.

# betaNB 1.0.4

## Patch

* Minor documentation edits.

# betaNB 1.0.3

## Patch

* Minor edits to setting seed.

# betaNB 1.0.2

## Patch

* Edits to documentation.

# betaNB 1.0.1

## Patch

* Edits to the DESCRIPTION file.

# betaNB 1.0.0

## Major

* And so it begins.
