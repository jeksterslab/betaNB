# betaNB 1.0.3.9000

* Latest development version.

# betaNB 1.0.3

## Patch

* Minor edits to setting seed.

# betaNB 1.0.2

## Patch

* Edits to documentation.

# betaNB 1.0.1

## Patch

* Edits to the DESCRIPTION file.

# betaNB 1.0.0

## Major

* And so it begins.
