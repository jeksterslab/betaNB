# betaNB 1.0.1

## Minor

* Edits to the DESCRIPTION file.

# betaNB 1.0.0

## Major

* And so it begins.
